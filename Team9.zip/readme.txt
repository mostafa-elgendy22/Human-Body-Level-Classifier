- Presentation link: https://docs.google.com/presentation/d/1kxhas24m8c_ymTxs_IjiSuE62Flt6Qio/edit?usp=sharing&ouid=115861314821770437334&rtpof=true&sd=true

- The perform_inference.py and model.pkl can be found in test directory